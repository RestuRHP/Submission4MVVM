package net.learn.submission4mvvm.objectdata

import net.learn.submission4mvvm.model.movies.Movie

class MovieObject {
    var results: List<Movie>? = null
}