package net.learn.submission4mvvm.objectdata

import net.learn.submission4mvvm.model.tv.TvShows

class TvShowsObject {
    var results: List<TvShows>? = null
}